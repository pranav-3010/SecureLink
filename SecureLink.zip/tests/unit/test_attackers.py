"""Unit tests verifying attacker behaviors and architectural isolation rules."""

import ast
from pathlib import Path
import pytest
from securelink.simulation.attacks.tamper import TamperAttacker
from securelink.simulation.attacks.replay import ReplayAttacker
from securelink.simulation.attacks.spoof import SpoofAttacker
from securelink.simulation.attacks.drop import DropAttacker
from securelink.simulation.channel import AdversarialChannel


def test_attacker_architectural_isolation():
    """Verify attackers never import from crypto/keystore, crypto/kdf, crypto/aead, or pipeline/rx_pipeline."""
    repo_root = Path(__file__).resolve().parents[2]
    attacks_dir = repo_root / "src/securelink/simulation/attacks"
    manual_dir = repo_root / "src/securelink/simulation/manual"
    py_files = list(attacks_dir.glob("*.py")) + list(manual_dir.glob("*.py"))
    py_files.append(repo_root / "src/securelink/simulation/channel.py")

    forbidden_modules = (
        "crypto.keystore",
        "crypto.kdf",
        "crypto.aead",
        "pipeline.rx_pipeline",
    )
    forbidden_names = {"KeyStore", "RxPipeline", "decrypt_gcm", "encrypt_gcm", "derive", "key_id"}

    for py_file in py_files:
        tree = ast.parse(py_file.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    assert not any(alias.name.endswith(fm) for fm in forbidden_modules), f"{py_file} imports forbidden {alias.name}"
                    assert alias.name not in forbidden_names, f"{py_file} imports forbidden symbol {alias.name}"
            elif isinstance(node, ast.ImportFrom):
                mod = node.module or ""
                assert not any(mod.endswith(fm) or fm in mod for fm in forbidden_modules), f"{py_file} imports from {mod}"
                for alias in node.names:
                    assert alias.name not in forbidden_names, f"{py_file} imports {alias.name} from {mod}"





def test_attackers_output_contract():
    sample_frame = b"\x01" * 120

    tamper = TamperAttacker()
    t_bytes, t_label = tamper.apply(sample_frame)
    assert t_label == "TAMPERED"
    assert t_bytes != sample_frame

    replay = ReplayAttacker()
    replay.record_frame(sample_frame)
    r_bytes, r_label = replay.apply(b"\x02" * 120)
    assert r_label == "REPLAYED"
    assert r_bytes == sample_frame

    spoof = SpoofAttacker()
    s_bytes, s_label = spoof.apply(sample_frame)
    assert s_label == "SPOOFED"
    assert s_bytes != sample_frame

    drop = DropAttacker()
    d_bytes, d_label = drop.apply(sample_frame)
    assert d_label == "DROPPED"
    assert d_bytes is None
