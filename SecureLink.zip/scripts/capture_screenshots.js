const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const CLEAN_FID = 'ddc486ef5dd045649c51017aaaab0603';
const ATTACKED_FID = '539f018133934f46a17ee0e93d072e84';

async function main() {
  const edgePath = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
  const port = 9223;
  const edgeProc = spawn(edgePath, [
    `--remote-debugging-port=${port}`,
    '--headless=new',
    '--disable-gpu',
    '--window-size=1600,1100',
    'about:blank'
  ]);

  await new Promise((r) => setTimeout(r, 1200));

  const listRes = await fetch(`http://127.0.0.1:${port}/json`);
  const pages = await listRes.json();
  const page = pages.find((p) => p.type === 'page') || pages[0];
  const ws = new WebSocket(page.webSocketDebuggerUrl);

  let id = 1;
  const pending = new Map();
  ws.onmessage = (e) => {
    const data = JSON.parse(e.data);
    if (data.id && pending.has(data.id)) {
      pending.get(data.id)(data.result);
      pending.delete(data.id);
    }
  };

  function send(method, params = {}) {
    return new Promise((resolve) => {
      const msgId = id++;
      pending.set(msgId, resolve);
      ws.send(JSON.stringify({ id: msgId, method, params }));
    });
  }

  await new Promise((r) => { ws.onopen = r; });
  await send('Page.enable');
  await send('Runtime.enable');

  console.log('Navigating to http://127.0.0.1:8000/#/lab...');
  await send('Page.navigate', { url: 'http://127.0.0.1:8000/#/lab' });
  await new Promise((r) => setTimeout(r, 2000));

  // --- 1. Clean File Screenshot ---
  console.log('Testing Clean File Results...');
  await send('Runtime.evaluate', {
    expression: `
      (async () => {
        const sel = document.getElementById('step-2-file-select');
        if (sel) {
          sel.value = '${CLEAN_FID}';
          sel.dispatchEvent(new Event('change'));
        }
        await new Promise(r => setTimeout(r, 600));
        const item4 = document.querySelector('.stepper-item[data-step="4"]');
        if (item4) item4.click();
        await new Promise(r => setTimeout(r, 400));
        const btnB = document.getElementById('btn-verify-baseline');
        if (btnB) btnB.click();
        await new Promise(r => setTimeout(r, 800));
        const s4 = document.getElementById('step-4-card');
        if (s4) s4.scrollIntoView({ behavior: 'instant', block: 'start' });
      })()
    `,
    awaitPromise: true,
  });

  await new Promise((r) => setTimeout(r, 1500));
  const cleanShot = await send('Page.captureScreenshot', { format: 'png' });
  fs.writeFileSync('docs/screenshots/lab_results_clean.png', Buffer.from(cleanShot.data, 'base64'));
  console.log('Saved docs/screenshots/lab_results_clean.png');

  // --- 2. Attacked File Screenshot ---
  console.log('Testing Attacked File Results...');
  await send('Runtime.evaluate', {
    expression: `
      (async () => {
        const item2 = document.querySelector('.stepper-item[data-step="2"]');
        if (item2) item2.click();
        await new Promise(r => setTimeout(r, 400));
        const sel = document.getElementById('step-2-file-select');
        if (sel) {
          sel.value = '${ATTACKED_FID}';
          sel.dispatchEvent(new Event('change'));
        }
        await new Promise(r => setTimeout(r, 600));
        const item4 = document.querySelector('.stepper-item[data-step="4"]');
        if (item4) item4.click();
        await new Promise(r => setTimeout(r, 400));
        const btnW = document.getElementById('btn-verify-working');
        if (btnW) btnW.click();
        await new Promise(r => setTimeout(r, 800));
        const s4 = document.getElementById('step-4-card');
        if (s4) s4.scrollIntoView({ behavior: 'instant', block: 'start' });
      })()
    `,
    awaitPromise: true,
  });

  await new Promise((r) => setTimeout(r, 1500));
  const attShot = await send('Page.captureScreenshot', { format: 'png' });
  fs.writeFileSync('docs/screenshots/lab_results_attacked.png', Buffer.from(attShot.data, 'base64'));
  console.log('Saved docs/screenshots/lab_results_attacked.png');

  // --- 3. Live Monitor Aligned Columns Screenshot ---
  console.log('Testing Live Monitor feed alignment...');
  await send('Page.navigate', { url: 'http://127.0.0.1:8000/#/monitor?mock=1' });
  await new Promise((r) => setTimeout(r, 1000));
  await send('Runtime.evaluate', {
    expression: `
      (async () => {
        const startBtn = document.getElementById('btn-start');
        if (startBtn && !startBtn.disabled) startBtn.click();
      })()
    `,
    awaitPromise: true,
  });
  await new Promise((r) => setTimeout(r, 3000));
  const monShot = await send('Page.captureScreenshot', { format: 'png' });
  fs.writeFileSync('docs/screenshots/monitor_aligned.png', Buffer.from(monShot.data, 'base64'));
  console.log('Saved docs/screenshots/monitor_aligned.png');

  edgeProc.kill();
  process.exit(0);
}

main().catch((err) => {
  console.error('Error during capture:', err);
  process.exit(1);
});
