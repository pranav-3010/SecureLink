// Canonical 8-Column Packet Feed Table Component for File Lab & Live Monitor
import { formatReason, formatTimestamp, verdictBadge, truthBadge, escapeHTML } from './verdictFormat.js';

export function createVerdictFeed(container, options = {}) {
  const mode = options.mode || 'fileLab'; // 'fileLab' (wire order) or 'liveMonitor' (newest first)
  const maxRows = options.maxRows || 50;
  const onSelectRow = options.onSelectRow || (() => {});

  let allRows = [];
  let displayedRows = [];
  let filterVerdict = null;
  let lastEpoch = null;
  let renderLimit = 200;

  container.innerHTML = `
    <div class="verdict-feed-container">
      <div class="feed-table-scroll" style="max-height: ${options.maxHeight || '460px'}; overflow-y: auto;">
        <table class="data-table feed-table">
          <thead>
            <tr>
              <th style="width:55px;">SEQ</th>
              <th style="width:65px;">EPOCH</th>
              <th style="width:75px;">SRC</th>
              <th style="width:105px;">VERDICT</th>
              <th>REASON</th>
              <th style="width:125px;">TRUTH</th>
              <th style="width:85px;">LATENCY</th>
              <th style="width:105px;">TIMESTAMP</th>
            </tr>
          </thead>
          <tbody class="feed-tbody">
            <tr class="placeholder-row"><td colspan="8" style="text-align:center; color:var(--text-dim); padding:24px;">No frames to display</td></tr>
          </tbody>
        </table>
      </div>
      <div class="feed-load-more" style="display:none; text-align:center; padding:8px; border-top:1px solid var(--border-color);">
        <button class="btn-tool btn-load-more" style="padding:4px 14px; font-size:11px;">Load More Frames...</button>
      </div>
    </div>
  `;

  const tbody = container.querySelector('.feed-tbody');
  const scrollWrap = container.querySelector('.feed-table-scroll');
  const loadMoreWrap = container.querySelector('.feed-load-more');
  const btnLoadMore = container.querySelector('.btn-load-more');

  if (btnLoadMore) {
    btnLoadMore.addEventListener('click', () => {
      renderLimit += 200;
      renderTable();
    });
  }

  // Infinite scroll trigger
  scrollWrap.addEventListener('scroll', () => {
    if (scrollWrap.scrollTop + scrollWrap.clientHeight >= scrollWrap.scrollHeight - 40) {
      if (renderLimit < displayedRows.length) {
        renderLimit += 200;
        renderTable();
      }
    }
  });

  function buildRowElement(row) {
    const tr = document.createElement('tr');
    const isDropped = Boolean(row.dropped || row.verdict === 'DROPPED');
    tr.className = `feed-row${isDropped ? ' feed-row-dropped' : ''}`;
    tr.dataset.eid = row.eid || '';
    if (row.seq != null) tr.dataset.seq = row.seq;

    const seqText = row.seq != null ? escapeHTML(row.seq) : (row.n != null ? escapeHTML(row.n) : '—');
    const epochText = row.epoch != null ? escapeHTML(row.epoch) : 1;
    const srcText = row.src || (row.sender_id != null ? `NODE-${row.sender_id}` : (row.line != null ? `line ${row.line}` : 'NODE-1'));
    const latencyText = row.latency_us != null ? `${Number(row.latency_us).toFixed(1)} µs` : '—';
    const timeText = formatTimestamp(row.t || row.ts);

    tr.innerHTML = `
      <td>${seqText}</td>
      <td>${epochText}</td>
      <td style="color:var(--text-dim);">${escapeHTML(srcText)}</td>
      <td>${verdictBadge(row.verdict)}</td>
      <td class="td-reason" title="${escapeHTML(row.reason)}">${escapeHTML(formatReason(row.reason))}</td>
      <td>${truthBadge(row.truth, row.caught)}</td>
      <td class="td-latency" style="color:var(--text-dim);">${latencyText}</td>
      <td style="color:var(--text-dim); font-size:11px;">${timeText}</td>
    `;

    tr.addEventListener('click', () => {
      tbody.querySelectorAll('.row-selected').forEach((r) => r.classList.remove('row-selected'));
      tr.classList.add('row-selected');
      onSelectRow(row, tr);
    });

    return tr;
  }

  function renderTable() {
    tbody.innerHTML = '';
    lastEpoch = null;

    if (!displayedRows || displayedRows.length === 0) {
      tbody.innerHTML = `<tr class="placeholder-row"><td colspan="8" style="text-align:center; color:var(--text-dim); padding:24px;">No frames match current filter</td></tr>`;
      if (loadMoreWrap) loadMoreWrap.style.display = 'none';
      return;
    }

    const rowsToRender = displayedRows.slice(0, renderLimit);
    const fragment = document.createDocumentFragment();

    rowsToRender.forEach((row) => {
      const ep = row.epoch;
      if (ep != null && lastEpoch !== null && ep !== lastEpoch) {
        const divRow = document.createElement('tr');
        divRow.className = 'epoch-divider-row';
        divRow.innerHTML = `<td colspan="8">─── ROTATION TO KEY EPOCH ${escapeHTML(ep)} (PREVIOUS: ${escapeHTML(lastEpoch)}) ───</td>`;
        fragment.appendChild(divRow);
      }
      if (ep != null) lastEpoch = ep;

      fragment.appendChild(buildRowElement(row));
    });

    tbody.appendChild(fragment);

    if (loadMoreWrap) {
      loadMoreWrap.style.display = renderLimit < displayedRows.length ? 'block' : 'none';
      if (btnLoadMore) {
        btnLoadMore.textContent = `Showing ${rowsToRender.length} of ${displayedRows.length} frames — Load More`;
      }
    }
  }

  function applyFilter() {
    if (!filterVerdict || filterVerdict === 'ALL') {
      displayedRows = allRows;
    } else {
      displayedRows = allRows.filter((r) => String(r.verdict || '').toUpperCase() === filterVerdict.toUpperCase());
    }
    renderLimit = 200;
    renderTable();
  }

  return {
    setData: (rows) => {
      allRows = Array.isArray(rows) ? rows : [];
      applyFilter();
    },
    setFilter: (verdict) => {
      filterVerdict = verdict;
      applyFilter();
    },
    pushLiveEvent: (ev) => {
      if (mode !== 'liveMonitor') return;
      const placeholder = tbody.querySelector('.placeholder-row');
      if (placeholder) placeholder.remove();

      // Check epoch divider
      if (ev.epoch != null && lastEpoch !== null && ev.epoch !== lastEpoch) {
        const divRow = document.createElement('tr');
        divRow.className = 'epoch-divider-row';
        divRow.innerHTML = `<td colspan="8">─── ROTATION TO KEY EPOCH ${escapeHTML(ev.epoch)} (PREVIOUS: ${escapeHTML(lastEpoch)}) ───</td>`;
        tbody.prepend(divRow);
      }
      if (ev.epoch != null) lastEpoch = ev.epoch;

      const rowEl = buildRowElement(ev);
      tbody.prepend(rowEl);

      while (tbody.children.length > maxRows) {
        tbody.removeChild(tbody.lastChild);
      }
    },
    clear: () => {
      allRows = [];
      displayedRows = [];
      tbody.innerHTML = `<tr class="placeholder-row"><td colspan="8" style="text-align:center; color:var(--text-dim); padding:24px;">No frames to display</td></tr>`;
      if (loadMoreWrap) loadMoreWrap.style.display = 'none';
    },
    scrollToItem: (eidOrSeq) => {
      const match = tbody.querySelector(`tr[data-eid="${eidOrSeq}"], tr[data-seq="${eidOrSeq}"]`);
      if (match) {
        tbody.querySelectorAll('.row-selected').forEach((r) => r.classList.remove('row-selected'));
        match.classList.add('row-selected');
        match.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    },
  };
}
