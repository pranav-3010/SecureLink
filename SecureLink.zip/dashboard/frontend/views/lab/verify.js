import { formatError, api } from '../../lib/api.js';
import { opVerify, opGetFileInfo } from '../lab_ops.js';
import { renderC2StreamTable, renderReconciliationTab } from '../lab_recon.js';
import { createVerdictCounters } from '../../components/verdictCounters.js';
import { createVerdictFeed } from '../../components/verdictFeed.js';
import { createIncidentLog } from '../../components/incidentLog.js';
import { openDrawer } from './components/drawer.js';

let activeFileId = null, onVerifiedCb = null, lastVerifyMode = 'working';
let countersCtrl = null, feedCtrl = null, incidentCtrl = null;
let lastBaselineSummary = null;

export function renderStep4HTML() {
  return `
    <div class="step-card" id="step-4-card">
      <div class="step-header" id="step-4-header">
        <div class="step-title-group">
          <span class="step-badge" id="step-4-badge">4</span>
          <span class="step-title">VERIFY & RESULTS</span>
          <span class="step-summary-text" id="step-4-summary" style="display:none;"></span>
        </div>
        <button class="btn-step-edit" id="step-4-edit-btn" style="display:none;">Edit</button>
      </div>

      <div class="step-content" id="step-4-content" style="display:none;">
        <!-- Verification Action & Download Toolbar -->
        <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:12px;flex-wrap:wrap;">
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <button class="btn btn-primary" id="btn-verify-working">Verify Working Copy</button>
            <button class="btn btn-secondary" id="btn-verify-baseline">Verify Baseline (Untouched)</button>
            <button class="btn-tool" id="btn-download-wire" style="padding:6px 10px;font-size:11px;">Download .wire</button>
            <button class="btn-tool" id="btn-download-c2" style="padding:6px 10px;font-size:11px;">Export C2 CSV</button>
          </div>
          <div id="verify-status-msg" style="font-size:11px;color:var(--text-dim);"></div>
        </div>

        <!-- Error Alert Callout -->
        <div id="verify-error-box" style="display:none;margin-bottom:12px;border:1px solid var(--c-red);background:rgba(255,51,102,0.12);padding:10px 14px;border-radius:4px;color:var(--c-red);font-size:11.5px;">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;">
            <span id="verify-error-text" style="word-break:break-word;"></span>
            <button class="btn btn-outline-danger btn-sm" id="btn-verify-retry" style="font-size:10px;padding:2px 8px;white-space:nowrap;">Retry</button>
          </div>
        </div>

        <!-- Baseline Clean & Comparison Banner -->
        <div id="baseline-clean-banner" style="display:none;margin-bottom:12px;padding:8px 12px;border-radius:4px;border:1px solid rgba(0,255,136,0.3);background:rgba(0,255,136,0.08);color:var(--c-green);font-size:11.5px;font-weight:600;">
          &#10003; Baseline Clean: 100% Authentic &mdash; Untouched original passes all crypto, epoch &amp; replay checks.
        </div>
        <div id="baseline-compare-strip" style="display:none;margin-bottom:12px;padding:8px 12px;border-radius:4px;border:1px solid var(--border-color);background:rgba(0,0,0,0.25);font-size:11px;color:var(--text-dim);">
          <span id="compare-text"></span>
        </div>

        <!-- Results Sub-Tabs -->
        <div class="sub-tab-bar" style="margin-bottom:12px;">
          <button class="sub-tab active" id="tab-v-feed">Packet Feed &amp; Incidents</button>
          <button class="sub-tab" id="tab-v-c2">Decoded C2 Stream</button>
          <button class="sub-tab" id="tab-v-recon">Reconciliation Audit</button>
        </div>

        <!-- Tab 1: Live Monitor Style Results (Counters + 2/3 Feed + 1/3 Incidents) -->
        <div id="panel-v-feed" class="sub-tab-panel">
          <div id="lab-counters-host"></div>
          <div class="lab-results-grid">
            <div class="panel" style="min-width:0;">
              <div class="panel-header">
                <h3>VERIFIED WIRE FEED</h3>
                <span class="hud-subtext" id="lab-feed-subtext">Wire Order \u2022 Wire Lines 1..N</span>
              </div>
              <div id="lab-feed-host" style="padding:0;"></div>
            </div>
            <div class="panel" style="min-width:0;">
              <div class="panel-header">
                <h3>SECURITY INCIDENT LOG</h3>
                <span class="hud-subtext">In-Memory ACK</span>
              </div>
              <div id="lab-incidents-host" style="padding:10px;"></div>
            </div>
          </div>
        </div>

        <!-- Tab 2: Clean C2 Stream Panel -->
        <div id="panel-v-c2" class="sub-tab-panel" style="display:none;">
          <div id="c2-stream-banner" style="margin-bottom:8px;font-size:11.5px;color:var(--c-cyan);">Clean C2 Output Stream</div>
          <div class="table-responsive">
            <table class="data-table" style="width:100%;"><thead id="c2-stream-thead"></thead><tbody id="c2-stream-tbody"></tbody></table>
          </div>
        </div>

        <!-- Tab 3: Reconciliation Audit Panel -->
        <div id="panel-v-recon" class="sub-tab-panel" style="display:none;">
          <div class="dashboard-grid" id="recon-audit-cards" style="margin-bottom:12px;"></div>
          <div id="recon-audit-details" style="background:rgba(0,0,0,0.2);padding:14px;border-radius:4px;border:1px solid var(--border-color);line-height:1.6;font-size:11.5px;"></div>
        </div>
      </div>
    </div>
  `;
}

function initControllers() {
  const countersHost = document.getElementById('lab-counters-host');
  const feedHost = document.getElementById('lab-feed-host');
  const incidentsHost = document.getElementById('lab-incidents-host');

  if (countersHost && !countersCtrl) {
    countersCtrl = createVerdictCounters(countersHost, {
      onFilterChange: (verdict) => {
        if (feedCtrl) feedCtrl.setFilter(verdict);
      },
    });
  }

  if (feedHost && !feedCtrl) {
    feedCtrl = createVerdictFeed(feedHost, {
      mode: 'fileLab',
      maxHeight: '440px',
      onSelectRow: (row) => {
        if (activeFileId && row.eid) openDrawer(activeFileId, row.eid);
      },
    });
  }

  if (incidentsHost && !incidentCtrl) {
    incidentCtrl = createIncidentLog(incidentsHost, {
      maxHeight: '400px',
      onSelectIncident: (inc) => {
        if (feedCtrl) feedCtrl.scrollToItem(inc.eid || inc.seq);
      },
      onAck: async () => {
        // Purely local in-memory ACK for File Lab results (does not write to live /api/incidents)
      },
    });
  }
}

export function initStep4(fileId, options = {}) {
  activeFileId = fileId;
  onVerifiedCb = options.onVerified || null;

  initControllers();

  const byId = (id) => document.getElementById(id);
  byId('btn-verify-working')?.addEventListener('click', () => runVerification('working'));
  byId('btn-verify-baseline')?.addEventListener('click', () => runVerification('original'));
  byId('btn-verify-retry')?.addEventListener('click', () => runVerification(lastVerifyMode));

  byId('btn-download-wire')?.addEventListener('click', () => {
    if (activeFileId) window.open(`/api/lab/files/${activeFileId}/download?view=${lastVerifyMode}`, '_blank');
  });
  byId('btn-download-c2')?.addEventListener('click', () => exportCleanCSV());

  byId('tab-v-feed')?.addEventListener('click', () => switchTab('feed'));
  byId('tab-v-c2')?.addEventListener('click', () => switchTab('c2'));
  byId('tab-v-recon')?.addEventListener('click', () => switchTab('recon'));
}

export async function setStep4File(fileId) {
  activeFileId = fileId;
  initControllers();
  const btnB = document.getElementById('btn-verify-baseline');
  if (!btnB) return;
  try {
    const info = await opGetFileInfo(fileId);
    const isUploadedWithoutParent = info?.meta?.source_kind === 'upload' && !info?.parent_id;
    btnB.disabled = Boolean(isUploadedWithoutParent);
    btnB.style.opacity = isUploadedWithoutParent ? '0.5' : '1';
    btnB.style.cursor = isUploadedWithoutParent ? 'not-allowed' : 'pointer';
  } catch (_) {}
}

export async function runVerification(mode = 'working') {
  if (!activeFileId) return;
  lastVerifyMode = mode;
  initControllers();

  const statusEl = document.getElementById('verify-status-msg');
  const errBox = document.getElementById('verify-error-box');
  const btnW = document.getElementById('btn-verify-working');
  const btnB = document.getElementById('btn-verify-baseline');

  if (errBox) errBox.style.display = 'none';
  if (btnW) btnW.disabled = true;
  if (btnB) btnB.disabled = true;
  if (statusEl) statusEl.textContent = 'Verifying frames...';

  try {
    const vData = await opVerify(activeFileId, mode);
    renderVerificationResults(vData, mode);
    if (onVerifiedCb) onVerifiedCb(vData.summary, mode);
  } catch (err) {
    if (errBox) {
      errBox.style.display = 'block';
      const errText = document.getElementById('verify-error-text');
      if (errText) errText.textContent = formatError(err);
    }
  } finally {
    if (btnW) btnW.disabled = false;
    if (btnB) btnB.disabled = false;
    if (statusEl) statusEl.textContent = '';
  }
}

function renderVerificationResults(vData, mode) {
  const sum = vData.summary || {};
  const feedData = vData.feed || {};
  const rows = feedData.rows || vData.rows || [];
  const counts = feedData.counts || {
    AUTHENTIC: sum.authentic || 0,
    TAMPERED: 0, REPLAYED: 0, SPOOFED: 0, DROPPED: 0, OTHER: 0,
    total: sum.total || rows.length,
  };
  const incidents = feedData.incidents || [];

  if (countersCtrl) countersCtrl.setCounts(counts);
  if (feedCtrl) feedCtrl.setData(rows);
  if (incidentCtrl) incidentCtrl.setIncidents(incidents);

  const baseBanner = document.getElementById('baseline-clean-banner');
  const compStrip = document.getElementById('baseline-compare-strip');
  const compText = document.getElementById('compare-text');

  if (mode === 'original') {
    lastBaselineSummary = sum;
    if (baseBanner) baseBanner.style.display = (sum.authentic === sum.total) ? 'block' : 'none';
    if (compStrip) compStrip.style.display = 'none';
  } else {
    if (baseBanner) baseBanner.style.display = 'none';
    if (compStrip && compText) {
      const baseAuth = lastBaselineSummary ? lastBaselineSummary.authentic : sum.total;
      const baseTot = lastBaselineSummary ? lastBaselineSummary.total : sum.total;
      const suppressed = vData.delivery?.suppressed ?? 0;
      compText.textContent = `Clean baseline: ${baseAuth}/${baseTot} authentic (0 suppressed) \u2022 Working copy: ${sum.authentic || 0}/${sum.total || 0} authentic (${suppressed} suppressed)`;
      compStrip.style.display = 'block';
    }
  }

  renderC2StreamTable(vData.clean_output || [], vData.delivery || {});
  renderReconciliationTab(vData.delivery || {}, vData.gaps || []);
}

function switchTab(tab) {
  ['feed', 'c2', 'recon'].forEach((t) => {
    const tabBtn = document.getElementById(`tab-v-${t}`);
    const panel = document.getElementById(`panel-v-${t}`);
    if (tabBtn) tabBtn.classList.toggle('active', t === tab);
    if (panel) panel.style.display = t === tab ? 'block' : 'none';
  });
}

async function exportCleanCSV() {
  if (!activeFileId) return;
  try {
    const res = await api.get(`/api/lab/files/${activeFileId}/verify/last?mode=${lastVerifyMode}&view=clean&limit=5000`);
    const rows = res.rows || [];
    if (rows.length === 0) { alert('No clean C2 rows available to export.'); return; }
    const keys = Object.keys(rows[0]);
    const csv = [keys.join(','), ...rows.map((r) => keys.map((k) => JSON.stringify(r[k] ?? '')).join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `securelink-${activeFileId.slice(0, 8)}-clean.csv`;
    a.click();
    URL.revokeObjectURL(url);
  } catch (err) {
    alert('Failed to export clean C2 CSV: ' + formatError(err));
  }
}
