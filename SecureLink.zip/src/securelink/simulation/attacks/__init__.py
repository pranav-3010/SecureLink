"""Simulation attack modules."""
