"""Binary serialization and deserialization for SecureLink frames."""

import struct
from securelink.core.types import Header, SecureFrame
from securelink.core.errors import FrameMalformedError
from securelink.protocol.constants import (
    HEADER_FORMAT,
    HEADER_SIZE,
    SIGNATURE_SIZE,
    TAG_SIZE,
    MIN_FRAME_SIZE,
)


def pack_header(header: Header) -> bytes:
    """Pack Header dataclass into 20 big-endian bytes."""
    return struct.pack(
        HEADER_FORMAT,
        header.version,
        header.sender_id,
        header.key_epoch,
        header.seq,
        header.timestamp,
    )


def unpack_header(data: bytes) -> Header:
    """Unpack 20 big-endian bytes into Header dataclass."""
    if len(data) < HEADER_SIZE:
        raise FrameMalformedError(
            f"Header data too short: {len(data)} bytes (expected {HEADER_SIZE})"
        )
    try:
        version, sender_id, key_epoch, seq, timestamp = struct.unpack(
            HEADER_FORMAT, data[:HEADER_SIZE]
        )
        return Header(
            version=version,
            sender_id=sender_id,
            key_epoch=key_epoch,
            seq=seq,
            timestamp=timestamp,
        )
    except struct.error as e:
        raise FrameMalformedError(f"Failed to unpack header: {e}") from e


def pack_frame(frame: SecureFrame) -> bytes:
    """Serialize SecureFrame into continuous byte sequence.

    Layout: Header (20B) || CiphertextWithTag (N+16B) || Signature (64B)
    """
    if len(frame.signature) != SIGNATURE_SIZE:
        raise FrameMalformedError(
            f"Signature must be exactly {SIGNATURE_SIZE} bytes, got {len(frame.signature)}"
        )
    if len(frame.ciphertext_with_tag) < TAG_SIZE:
        raise FrameMalformedError(
            f"Ciphertext with tag must be at least {TAG_SIZE} bytes, got {len(frame.ciphertext_with_tag)}"
        )

    header_bytes = pack_header(frame.header)
    return header_bytes + frame.ciphertext_with_tag + frame.signature


def unpack_frame(raw_bytes: bytes) -> SecureFrame:
    """Deserialize continuous byte sequence into SecureFrame."""
    if len(raw_bytes) < MIN_FRAME_SIZE:
        raise FrameMalformedError(
            f"Frame too short: {len(raw_bytes)} bytes (minimum {MIN_FRAME_SIZE} bytes)"
        )

    header_bytes = raw_bytes[:HEADER_SIZE]
    signature_bytes = raw_bytes[-SIGNATURE_SIZE:]
    ciphertext_with_tag = raw_bytes[HEADER_SIZE:-SIGNATURE_SIZE]

    if len(ciphertext_with_tag) < TAG_SIZE:
        raise FrameMalformedError("Ciphertext payload missing GCM tag")

    header = unpack_header(header_bytes)

    return SecureFrame(
        header=header,
        ciphertext_with_tag=ciphertext_with_tag,
        signature=signature_bytes,
    )
