"""Protocol constants for the SecureLink wire format."""

PROTOCOL_VERSION: int = 1
DEFAULT_KEY_EPOCH: int = 1

HEADER_FORMAT: str = ">BHBQd"
HEADER_SIZE: int = 20  # 1 (ver) + 2 (sender) + 1 (epoch) + 8 (seq) + 8 (ts)

SALT_SIZE: int = 4
NONCE_SIZE: int = 12  # 4 bytes salt + 8 bytes seq
TAG_SIZE: int = 16
SIGNATURE_SIZE: int = 64  # IEEE P1363 raw r (32B) + s (32B)

MIN_FRAME_SIZE: int = HEADER_SIZE + TAG_SIZE + SIGNATURE_SIZE  # 100 bytes
